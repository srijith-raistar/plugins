
export async function all(m) {
	
    // when someone sends a group link to the bot's dm
    if ((m.mtype === 'groupInviteMessage' || m.text.startsWith('https://chat') || m.text.startsWith('open this link')) && !m.isBaileys && !m.isGroup) {
     this.sendButton(m.chat, `*Invite bot to a group* 
        
  Hello, @${m.sender.split('@')[0]} 
  You Must Pay For Adding bot to your group...You Can Rent The Bot For 3$/month(55 rands) .If You're Ready To Pay For it...You can just dm the owner. +1 (251) 241-1646 
`.trim(), igfg, null, [['Okay💫', '/owner']] , m, { mentions: [m.sender] })
    m.react('💎')
  } 
  
   return !0
}
