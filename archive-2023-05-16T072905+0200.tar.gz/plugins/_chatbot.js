
import fetch from 'node-fetch'

export async function before(m, { conn }) {
if (m.isBaileys && m.fromMe)
        return !0
   // if (!m.isGroup) return !1
    let user = global.db.data.users[m.sender]
    
      if (!user.chatbot)
        return !0
        let api = await fetch(`https://api.simsimi.net/v2/?text=${m.text}&lc=en`)
        let res = await api.json()
        if(res.success!="I don't know what you're saying. Please teach me." && res.success!='please enter the text - text=hello')
        m.reply(res.success.replace('simsimi', 'Nancy 🐾').replace('Simsimi', 'Nancy❤️').replace('sim simi', 'Nancy🥰'))
    
}
