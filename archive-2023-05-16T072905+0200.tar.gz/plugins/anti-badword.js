/*const badRegex = /(sex|porn|boobs|dick|vagina|nude|xxx|fap|horny|ass|butt|blowjob|masturbat(e|ion)|penis|clit|suck(s|er)?|fuck(s|er|ing)?|cum|pussy|cunt|dildo|orgasm(s)?|jerk(s|ing)|erotic|kinky|naughty|dirty|filthy|raunchy|vulgar|lewd|obscene|perverted|smut|tease|strip(tease)?|fetish|gangbang|bondage|dominatrix|prostitute|whore|slut|naked|bare|breasts|genitalia|pubic|hentai|yaoi|yuri|furries|beastiality|incest|pedophilia|child porn|bestiality|golden shower|scat|watersports|diaper play|role play|phone sex|webcam sex|voyeur|exhibitionist|swinger|wife-swapping|threesome|orgy|fornication|adultery|cheating|homosexual|bisexual|transgender|transvestite|gender-bender|hermaphrodite|intersex|queer|gay|lesbian|tribbing|scissoring|pegging|fisting|anal(ingus)?|rimjob|taint|perineum|smegma|blue balls|coitus|cunnilingus|fellatio|pearl necklace|snowballing|titty fucking|vore|gore|snuff|suicide|self-harm|anorexia|bulimia|obesity|body shaming|rape|sexual assault|gang rape|date rape|statutory rape|molestation|peeping tom|upskirt|panty-sniffing|stalking|harassment|prostitution|pimp|sexting|nudes|camgirl|onlyfans|stripper|lap dance|pole dance|lapdance|pole dance|erotic dance|striptease|sex toy|dildo|vibrator|butt plug|anal beads|sex swing|sex machine|fleshlight|masturbation sleeve|pocket pussy|sex doll|blow-up doll|real doll|sex robot|cybersex|virtual sex|erotic fiction|pornography|erotica|jerk off|spank the monkey|handjob|rough sex|choking|hair-pulling|edgeplay|knife play|needle play|fire play|electricity play|wax play|impact play|whipping|caning|spanking|spanking bench|spanking horse|spanking paddle|spanking whip|corporal punishment|golden age of porn|deepthroat|gang bang|swingers|homemade porn|amateur porn|voyeurism|exhibitionism|public sex|dogging|glory hole|rimming|69|cowgirl|reverse cowgirl|missionary|doggy style|spooning|standing up|sex on the beach|anal sex|double penetration|triple penetration|quadruple penetration|gokkun|bukkake|cum)/i;


export async function before(m, { conn, isAdmin, isBotAdmin }) {
  if (m.isBaileys || m.fromMe) return true;
  if (!m.isGroup) return false;

  const chat = global.db.data.chats[m.chat];
  const who = m.sender;
  const bot = global.db.data.settings[this.user.jid] || {};

  const isBad = badRegex.test(m.text);
  const warn = global.db.data.users[who]?.warn || 0;
  const maxWarn = global.maxwarn;

  if (chat.antiBadword && isBad) {
    if (warn < maxWarn) {
       
      global.db.data.users[who].warn = warn + 1;
        await conn.sendMessage(m.chat, { delete: m.key });
      const message = `*💬 Bad Word Detected*
      
We do not allow bad words in this group.\n *@${m.sender.split('@')[0]}*  \nIf you repeat it, you will be kicked out from this group.`;
      await conn.reply(m.chat, message, null, { mentions: [m.sender] });
      
      if (isBotAdmin && chat.antiBad) {
        await conn.sendMessage(m.chat, { delete: m.key });
      } else if (!chat.antiBad) {
        return;
      }
    } else if(warn>=maxWarn){
            global.db.data.users[who].warn = 0
            m.reply(`⛔ The user exceeded the *${maxWarn}* warnings will therefore be removed`)
            await time(3000)
            await conn.groupParticipantsUpdate(m.chat, [who], 'remove')
            m.reply(`♻️ You were removed from the group *${groupMetadata.subject}* because you have been warned *${war}* times`, who)
      return false;
    }
  }

  return true;
}

function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}


const time = async (ms) => {
            return new Promise(resolve => setTimeout(resolve, ms));
        }
*/