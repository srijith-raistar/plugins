/*const cooldown = 1800000;

export async function all(m) {
  let user = global.db.data.users[m.sender];
  // let chats = global.db.data.chats[m.chat];
  if (!user.chatGPT && !user.groupgpt && !user.chatbot) {
    return true;
  } else {
    // Check if the user is under cooldown
    if (new Date() - user.aion < cooldown) {
      m.reply(`working 0`)//return true;
    } else {
      m.reply(user.aion);
      // m.reply(`Your Lover Is Offline Now...\n\n💘Use *\on gfbot* or *\on bfbot* to call your lover online.\n\nuse *\off gfbot* or *\off bfbot* to turn off.`)
      // await user.chatGPT=false
      // await user.groupgpt=false
      // user.chatbot=false
    }
  }
}
*/