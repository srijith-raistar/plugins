let handler = async (m, { conn }) => {
  //let name = conn.getName(m.sender)
//let user = global.db.data.users[m.sender]
await m.reply(m.sender)
global.db.data.users[m.sender].chatHistory = '';

}

handler.customPrefix = /^(resetgf)$/i
handler.command = new RegExp

export default handler

function pickRandom(list) {
  return list[Math.floor(list.length * Math.random())]
}
