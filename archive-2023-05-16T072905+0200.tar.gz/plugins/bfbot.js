import fetch from 'node-fetch'

export async function before(m, { conn }) {
  if (m.isBaileys && m.fromMe) return !0
  // if (!m.isGroup) return !0
  let user = global.db.data.users[m.sender]
  let chat = global.db.data.chats[m.chat]
  let name2 = conn.getName(m.sender)
  let gfname = "Andrew"
  
  if (!user.groupgpt) return !0
  let msg = `if i have a boyfriend,
    My name is ${name2},
    his name is ${gfname},
    What would be his reply when i send : ${m.text}
    (reply like a man)
    (Note:he can be naughty instead of telling lets talk about sometimg elshe can be naughty instead of telling lets talk about sometm lhe can be naughty instead of telling lets talk about sometimg elshe can be naughty instead of telling lets talk about somet he can be naughty instead of telling lets talk about sometimg elshe can be naughty instead of telling lets talk about sometm lhe can be naughty instead of telling lets talk about sometimg elshe can be naughty instead of telling lets talk about somet e
    dont reply in reported speech
    And reply within 15 words)`
        
  /*` (reply within 15 words)(dont use yourname un nessarly)(dont say my name in your sentance when not needed)(dont annoy by telling i love you, start any topic to talk instead but you can tell i love you sometime, like... when i says to you or i sends kissing emojis)\n\nnote : reply as you are my girlfriend, and your name is ${gfname} and my name is ${myname}(only use it if needed)`*/
  
  
  // Add a random delay of 1-4 seconds
  const delay = Math.floor(Math.random() * 4) + 1
  await new Promise(resolve => setTimeout(resolve, delay * 1000))
  
  let tiores = await fetch(`https://api.lolhuman.xyz/api/openai?apikey=${lolkeysapi}&text=${msg}&user=user-unique-id`)
  let hasil = await tiores.json()
  m.reply(`${hasil.result}`.trim().replace(`"`," ").replace("Andrew: "," ").replace(`"`," ").replace("Andrew might reply"," ").replace("Andrew would reply"," "))
}
