let handler = async (m, { text }) => {
  const url = 'https://api.coindesk.com/v1/bpi/currentprice.json';

  fetch(url)
    .then(response => response.json())
    .then(data => {
      const { USD, GBP, EUR } = data.bpi;

      const formattedData = [
        `💹 *SRIJISER-BOT GLOBAL ECONOMIC* 📈\n`,
        `💘 *Bitcoin Price Index (USD)* : $ ${USD.rate}`,
        `💘 *Currency* Info : ${USD.description}`,
        `💘 *British Pound Sterling (GBP)* : £ ${GBP.rate}`,
        `💘 *Euro (EUR)* : € ${EUR.rate}`,
        `🏮 *Last Updated* : *${data.time.updated}*`
      ].join('\n');

      m.reply(formattedData); // reply with the formatted data
    })
    .catch(error => console.log(error));
}

handler.help = ['tools'];
handler.tags = ['tools'];
handler.command = ['bitcoin'];

export default handler;
