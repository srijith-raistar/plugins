let handler = async (m, { text }) => {
   let fex = (text && /^\d+$/.test(text) && text >= 1 && text <= 100) ? parseInt(text) : 10; 

  fetch('https://api.coincap.io/v2/assets')
    .then(response => response.json())
    .then(data => {
      const assets = data.data;
      let message = '💹 *𝐒𝐑𝐈𝐉𝐈𝐒𝐄𝐑 𝐆𝐋𝐎𝐁𝐀𝐋 𝐄𝐂𝐎𝐍𝐎𝐌𝐘* 💰\n\n\n';
      for (let i = 0; i < fex; i++) {
        const asset = assets[i];
        message += `*${asset.rank}. ${asset.name} (${asset.symbol})* :\n\n`;
        message += `    *Price* : $${parseFloat(asset.priceUsd).toFixed(2)}\n`;
        message += `    *Supply : ${parseFloat(asset.supply).toFixed(2)} ${asset.symbol}*\n`;
        message += `    *Market Cap* : $${parseFloat(asset.marketCapUsd).toFixed(2)}\n`;
        message += `    *Volume (24h)* : $${parseFloat(asset.volumeUsd24Hr).toFixed(2)}\n\n`;
      }
      m.reply(message);
    })
    .catch(error => console.error(error));
}

handler.help = ['tools']
handler.tags = ['tools']
handler.command = ['bitrank']

export default handler
