import fetch from 'node-fetch'

let handler = async (m, { conn, text, usedPrefix, command }) => {
	
 let name = conn.getName(m.sender)
  if (!text) throw `Hii *${name}* want to talk? \nrespond *${usedPrefix + command}* 17+38`
  m.react('🗣️') 
  //let res = await fetch(global.API('https://api.simsimi.net', '/v2/', { text: encodeURIComponent(m.text), lc: "es" }, ''))
  let sreq = encodeURIComponent(text);
  let res = await fetch(`http://api.mathjs.org/v4/?expr=${sreq}`)
  let json = await res.json()
  if (json.success) m.reply(json.success)
  else throw json
}
handler.help = ['tools']
handler.tags = ['tools']
handler.command = ['calculator','calcular','calculadora','calculate','calc'] 

export default handler



