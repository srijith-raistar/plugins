
import { youtubedl, youtubedlv2 } from '@bochilteam/scraper'
import yts from 'yt-search'
var handler = async (m, { conn, command, text, usedPrefix }) => {
  if (!text) throw `Use example ${usedPrefix}${command} Alone pt2`
  await m.react(`💘`)
  let search = await yts(text)
  let vid = search.videos[Math.floor(Math.random() * search.videos.length)]
  if (!search) throw 'Audio Not Found, Try Another Title'
  let { title, thumbnail, timestamp, views, ago, url } = vid
 // let wm = 'Downloading audio please wait...'
 let hshs
  let captvid = `╭═══〘 ⭐⭐⭐⭐⭐⭐⭐ 〙══╮
║     ◉— *𝖸𝖮𝖴𝖳𝖴𝖡𝖤 𝖣𝖮𝖶𝖭𝖫𝖮𝖠𝖣𝖤𝖱* —◉
║≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡║
║⭐ Title: ${title}
║🥶 Duration: ${timestamp}
║💬 Views: ${views}
║✨ Upload: ${ago}
║🧚 Link: ${url}
╰═══╡⭐⭐⭐⭐⭐⭐⭐╞═══╯`
 /*conn.sendButton(*/ 
   global.db.data.chats[m.sender].hshs=url
 
  m.reply(/*m.chat, */`╭═══〘 ⭐⭐⭐⭐⭐⭐⭐ 〙══╮ 
║     ◉— *𝖸𝖮𝖴𝖳𝖴𝖡𝖤 𝖣𝖮𝖶𝖭𝖫𝖮𝖠𝖣𝖤𝖱* —◉
║≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡║
║⭐ Title: ${title}
║🥶 Duration: ${timestamp}
║💬 Views: ${views}
║✨ Upload: ${ago}
║🧚 Link: ${url}
╰═══╡⭐⭐⭐⭐⭐⭐⭐╞═══╯`
                        
    /*, author.trim(), await( await conn.getFile(thumbnail)).data, ['VIDEO', `${usedPrefix}ytmp4 ${url} 360`], false, { quoted: m, 'document': { 'url':'https://wa.me/919744504738' }, //https://wa.me/917605902011
'mimetype': global.dpdf,
'fileName': `𝖲𝖱𝖨𝖩𝖨𝖲𝖤𝖱-𝖬𝖴𝖲𝖨𝖢 𝖯𝖫𝖠𝖸𝖤𝖱...`,
'fileLength': 666666666666.66,
'pageCount': 66666666,contextInfo: { externalAdReply: { showAdAttribution: true,
mediaType:  2,
mediaUrl: `${url}`,
title: `𝖣𝖮𝖶𝖭𝖫𝖮𝖠𝖣𝖤𝖣 𝖴𝖲𝖨𝖭𝖦 𝖲𝖱𝖨𝖩𝖨𝖲𝖤𝖱-𝖬𝖴𝖲𝖨𝖢 𝖯𝖫𝖠𝖸𝖤𝖱...`,
body: wm,
sourceUrl: 'http://wa.me/917605902011', thumbnail: await ( await conn.getFile(thumbnail)).data
  }
 } 
}*/)
//global.db.data.chats[m.chat].hshs=url

  //let buttons = [{ buttonText: { displayText: '📽VIDEO' }, buttonId: `${usedPrefix}ytv ${url} 360` }]
 //let msg = await conn.sendMessage(m.chat, { image: { url: thumbnail }, caption: captvid, footer: author, buttons }, { quoted: m })

  const yt = await youtubedlv2(url).catch(async _ => await youtubedl(url))
const link = await yt.audio['128kbps'].download()
  let doc = { 
  audio: 
  { 
    url: link 
}, 
mimetype: 'audio/mp4', fileName: `${title}`/*, contextInfo: { externalAdReply: { showAdAttribution: false,
mediaType:  2,
mediaUrl: url,
title: title,
body: wm,
sourceUrl: url,
thumbnail: await(await conn.getFile(thumbnail)).data                                            
                                                                                                                 }
  }*/
  }
   m.reply(`🪄 Wanna Download Its Video? Type "Video"`)
  return conn.sendMessage(m.chat, doc, { quoted: m })
    
	// return conn.sendMessage(m.chat, { document: { url: link }, mimetype: 'audio/mpeg', fileName: `${title}.mp3`}, { quoted: m})
	// return await conn.sendFile(m.chat, link, title + '.mp3', '', m, false, { asDocument: true })
}
handler.help = ['play'].map(v => v + ' <query>')
handler.tags = ['downloader']
handler.command = /^(play|audio)$/i

handler.exp = 0
handler.diamond = false

export default handler
