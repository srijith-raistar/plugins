
import { youtubeSearch } from '@bochilteam/scraper'
import yts from 'yt-search'
let handler = async(m, { conn, usedPrefix, text, args, command }) => {

    if (!text) throw `✳️ Enter a song title\n\n*📌 Example*\n*${usedPrefix + command}* Lil Peep hate my fuccn life `
    m.react('🪄')
    let result = await yts(text)
    let ytres = result.all
    let listSections = []
	Object.values(ytres).map((v, index) => {
	listSections.push([`${index}┃ ${v.title}`, [
          ['🎶 MP3', `${usedPrefix}yta ${v.url}`, `▢ ⌚ *Duration:* ${v.timestamp}\n▢ 👀 *Views:* ${v.views}\n▢ 📌 *Títle* : ${v.title}\n▢ 📆 *Publiced:* ${v.ago}\n`],
          ['🎥 MP4', `${usedPrefix}ytv ${v.url}`, `▢ ⌚ *Duratión:* ${v.timestamp}\n▢ 👀 *Views:* ${v.views}\n▢ 📌 *Títle* : ${v.title}\n▢ 📆 *Publiced:* ${v.ago}\n`]
        ]])
	})
    if(m.isGroup)m.reply(`click on the link to continue :) \n\nwa.me/%31%32%3514%3946%36%37%37?text=/%70%6Ca%792%20${encodeURIComponent(text)}`)
	return conn.sendList(m.chat, '  💘 *SRIJISER-MUSIC PLAYER*🔎', `\n 📀 Here a list of results from :\n *${text}*`, igfg, `Click Here`, listSections, m)
}
handler.help = ['play2']
handler.tags = ['dl']
handler.command = ['play2', 'v2', 'playlist', 'playlista'] 

export default handler
