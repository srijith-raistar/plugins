const dir = [
  'https://images.alphacoders.com/789/789452.jpg',
  'https://images.alphacoders.com/789/789452.jpg',
  'https://images.alphacoders.com/789/789452.jpg',
  'https://images2.alphacoders.com/711/711450.jpg',
  'https://images6.alphacoders.com/793/793238.png',
  'https://images8.alphacoders.com/715/715125.png',
  'https://images6.alphacoders.com/712/712175.jpg',
  'https://images6.alphacoders.com/712/712175.jpg',
  'https://images5.alphacoders.com/539/539146.jpg',
  'https://images6.alphacoders.com/588/588405.jpg',
  'https://images8.alphacoders.com/528/528719.jpg', 
  'https://images7.alphacoders.com/539/539147.jpg'
];
let handler = async (m, { conn }) => {
  conn.sendFile(m.chat, dir[Math.floor(Math.random() * dir.length)], 'dado.webp', '', m)
}
handler.help = ['dado']
handler.tags = ['game']
handler.command = ['8kwall','wallpapper8k','8kwallpaper','wallpaper'] 

export default handler

