//import db from '../lib/database.js'

let handler = async (m) => {
    let alldb=global.db.data.users[m.sender]
   let nam= alldb.name
   m.reply(nam)
    
    
    
    }


handler.help = ['cmd']
handler.tags = ['cmd']
handler.command = ['getdb']
handler.owner = true

export default handler