import fetch from 'node-fetch'

export async function before(m, { conn }) {

  if (m.isBaileys && m.fromMe)
    return !0
  // if (!m.isGroup) return !1
  let user = global.db.data.users[m.sender]
  let chat = global.db.data.chats[m.chat]

  let name2 = conn.getName(m.sender)
  let gfname
  let myname
  
  
  // Function to add a message to the chat history for a user
function addMessage(user, message) {
  // If the chat history for the user does not exist yet, initialize it as an empty string
  if (!global.db.data.users[m.sender].chatHistory) {
    global.db.data.users[m.sender].chatHistory = '';
  }

  // Add the new message to the chat history for the user, prefixed with the user's name
  global.db.data.users[m.sender].chatHistory += user + ': ' + message + '\n';

  // Split the chat history into an array of messages using the newline character as the delimiter
  const messages = global.db.data.users[m.sender].chatHistory.trim().split('\n');

  // If the number of messages exceeds 5, remove the oldest message
  if (messages.length > 5) {
    // Remove the oldest message from the array
    messages.shift();

    // Join the remaining messages into a single string
    global.db.data.users[m.sender].chatHistory = messages.join('\n') + '\n';
  }
}
if (!user.chatGPT)
    return !0
  
  if (m.sender == `919744504738@s.whatsapp.net`) {
    gfname = "Arya"
    myname = "Sriji"
  }
  else {
    gfname = "nancy"
    myname = name2
  }
addMessage('Me', `${m.text}`);
  let msg = `my lover mostly reply within 15 words. she only speaks english.)
she is my lover and soulmate. so she can share anything with me
My name is ${myname} 
My Lover's Name is ${gfname} and age is 18

${user.chatHistory}\nMe : ${m.text}\nShe : `

  /*` (reply within 15 words)(dont use yourname un nessarly)(dont say my name in your sentance when not needed)(dont annoy by telling i love you, start any topic to talk instead but you can tell i love you sometime, like... when i says to you or i sends kissing emojis)\n\nnote : reply as you are my girlfriend, and your name is ${gfname} and my name is ${myname}(only use it if needed)`*/
  

  // Generate a random number between 1-10 and store it in a variable named 'delay'


function pickrandom() {
  const probabilities = [
    { number: 1, probability: 0.16 },
    { number: 2, probability: 0.16 },
    { number: 3, probability: 0.16 },
    { number: 4, probability: 0.16 },
    { number: 5, probability: 0.25 },
    { number: 6, probability: 0.25 },
    { number: 7, probability: 0.32 },
    { number: 8, probability: 0.32 },
    { number: 9, probability: 0.32 },
    { number: 10, probability: 0.1 },
    { number: 11, probability: 0.1 },
    { number: 12, probability: 0.1 },
    { number: 13, probability: 0.1 },
    { number: 14, probability: 0.07 },
    { number: 15, probability: 0.07 },
  ];

  let rand = Math.random();
  let cumulativeProbability = 0;

  for (let i = 0; i < probabilities.length; i++) {
    cumulativeProbability += probabilities[i].probability;
    if (rand < cumulativeProbability) {
      return probabilities[i].number;
    }
  }

  return -1; // This should never happen, but just in case
 }
  
  const delay = pickrandom();
  
  // Wait for 'delay' seconds before sending the reply
  await new Promise(resolve => setTimeout(resolve, delay * 1000));
  
  let tiores = await fetch(`https://api.lolhuman.xyz/api/openai?apikey=${lolkeysapi}&text=${msg}&user=user-unique-id`)
  let hasil = await tiores.json()
  let replyy= `${hasil.result}`.trim().replace(`"`, "").replace(`"`, "").replace("Arya: ", " ").replace("Nancy:", "").replace("Arya might reply", " ").replace("Nancy might reply,"," ").replace("Nancy might reply"," ")
  if (replyy=='Bye! Have a great day!'||replyy=='Goodbye! Have a great day!'||replyy=='Bye, take care!'||replyy=='Sure, see you later!'||replyy=='Have a great day!'){user.chatGPT = false
                                        m.react(`👋`)
                                       await m.reply(`*Your gf is offline*\nYou Can Simply Call Her Online By sending :  \n*/on gf*`)}
 if(m.text!==''){await m.reply(replyy)
addMessage('She', `${replyy}`);} console.log(` `)
}