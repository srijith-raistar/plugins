/*
let handler = async (m, { conn}) => {

let name = conn.getName(m.sender)
let av = `./src/mp3/${pickRandom(["install"])}.mp3`

//conn.sendButton(m.chat, `Hello *${name}* \n \nNeed help? \n`, igfg, null, [
     // ['⦙☰ Menu', '/help'],
     // ['⦙☰ Menu 2', '/menu2'],
    //  ['⌬ Groups', '/gpdylux']
    //], m)
m.react(`👨‍💻`)
conn.sendFile(m.chat, av, 'audio.mp3', null, m, true, { type: 'audioMessage', ptt: true })
} 

handler.customPrefix = /^(install|.install)$/i
handler.rowner = true
handler.command = new RegExp

export default handler

function pickRandom(list) {
  return list[Math.floor(list.length * Math.random())]
}
*/