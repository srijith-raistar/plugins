let handler = async m => m.reply(`

≡  *𝑆𝑅𝛪𝐽𝛪𝑆𝜩𝑅-𝜝𝜪𝑇*   GRUPOS

─────────────
💘 Join public bot group and support
https://chat.whatsapp.com/Hi9Xk33SviV9d3t5henKOg



─────────────
≡ Disabled links? enter here! 

▢ Get Help From Admin
 wa.me/12512411646?text=bot+help
─────────────
▢ *Owner Telegram*
 https://t.me/ [NOT AVAILABLE FOR NOW]

▢ *YouTube*
• https://www.youtube.com/@Sriji_Ser


`.trim())
handler.help = ['Contact']
handler.tags = ['main']
handler.command = ['groups', 'group','allgroups','botgroup','listgroups','gpbot'] 

export default handler
