
function handler(m) {
  const data = global.owner.filter(([id, isCreator]) => id && isCreator)
  //this.sendContact(m.chat, data.map(([id, name]) => [id, name]), m)
  m.reply(`🍓JOIN FOR ANY HELP : ~*https://chat.whatsapp.com/Hi9Xk33SviV9d3t5henKOg*~\n\n\n💘 CONTACT OWNER : ~*+1 (251) 241-1646*~`)

}

handler.help = ['owner']
handler.tags = ['main']
handler.command = ['owner', 'creator', 'creador', 'dueño', 'Gowner'] 

export default handler
