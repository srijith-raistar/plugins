
//import db from '../lib/database.js'

const rewards = {
  diamond: 10,
  money: 7999,
  potion: 6,
  
}
const cooldwn = 43200000

let handler = async (m,{ conn} ) => {
  let user = global.db.data.users[m.sender]
  if(m.isGroup)m.reply(`Wrong Code🚫🚫🚫`)
  if (new Date - user.lastclaimdim < cooldwn) throw `You have already claimed this daily claim!, wait for *${((user.lastclaimdim + cooldwn) - new Date()).toTimeString()}*`
  let text = ''
  for (let reward of Object.keys(rewards)) {
    if (!(reward in user)) continue
      if(m.isGroup)m.reply(`Wrong Code🚫🚫🚫`)
      user[reward] += rewards[reward]
     // user.diamond += dmt
    
    text += `*+${rewards[reward]}* ${global.rpg.emoticon(reward)}${reward}\n`
  }
  if(m.isGroup)m.reply(`Wrong Code🚫🚫🚫`)
    {
  conn.sendButton(m.chat,'*––––––『 🪄 DAILY CRATE 📦 』––––––*', text.trim(), null, [['Chek Balance', '.bal'], ['Shop', '.buy']],m)
  user.lastclaimdim = new Date * 1}
}
handler.help = ['bonus']
handler.tags = ['xp']
handler.command = /^(CLAIM-DAILY-CODE=GG99GX)$/i
handler.cooldwn = cooldwn

export default handler



function msToTime(duration) {
  var milliseconds = parseInt((duration % 1000) / 100),
    seconds = Math.floor((duration / 1000) % 60),
    minutes = Math.floor((duration / (1000 * 60)) % 60),
    hours = Math.floor((duration / (1000 * 60 * 60)) % 24)

  hours = (hours < 10) ? "0" + hours : hours
  minutes = (minutes < 10) ? "0" + minutes : minutes
  seconds = (seconds < 10) ? "0" + seconds : seconds

  return hours + " Horas " + minutes + " Minutos"
}