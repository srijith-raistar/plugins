let handler = async (m, { conn, args, text, usedPrefix, command }) => {
      let tee = `✳️ Enter a short text\n\n📌 Example  : *${usedPrefix + command}* Sriji`
    m.react(rwait)
    if (!text) throw tee 
	const dir = [
  `https://cataas.com/cat/says/${text}`,
];
   conn.sendFile(m.chat, dir[Math.floor(Math.random() * dir.length)], 'dado.webp', '', m)
  
    m.react(done)
    
/*const dir = [
  'https://cataas.com/cat/says/Hello',
];
  conn.sendFile(m.chat, dir[Math.floor(Math.random() * dir.length)], 'dado.webp', '', m)*/
}
handler.help = ['cat']
handler.tags = ['img']
handler.command = ['cat'] 

export default handler

