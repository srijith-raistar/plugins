import fetch from 'node-fetch'

let handler = async function (m, { conn, text, usedPrefix }) {
m.react(`🪽`)  
let m2 = `
*New Emojis in Version 15.0*


🫨 Shaking Face
🩷 Pink Heart
🩵 Light Blue Heart
🩶 Grey Heart
🫏 Donkey
🫎 Moose
🪿 Goose
🪽 Wing
🪼 Jellyfish
🪻 Hyacinth
🫛 Pea Pod
🫚 Ginger
🪭 Folding Hand Fan
🪮 Hair Pick
🪈 Flute
🪇 Maracas
🪯 Khanda
🛜 Wireless
🫸 Rightwards Pushing Hand
🫷 Leftwards Pushing Hand
🐦‍⬛ Black Bird
🫸🏻 Rightwards Pushing Hand: Light Skin Tone
🫸🏼 Rightwards Pushing Hand: Medium-Light Skin Tone
🫸🏽 Rightwards Pushing Hand: Medium Skin Tone
🫸🏾 Rightwards Pushing Hand: Medium-Dark Skin Tone
🫸🏿 Rightwards Pushing Hand: Dark Skin Tone
🫷🏻 Leftwards Pushing Hand: Light Skin Tone
🫷🏼 Leftwards Pushing Hand: Medium-Light Skin Tone
🫷🏽 Leftwards Pushing Hand: Medium Skin Tone
🫷🏾 Leftwards Pushing Hand: Medium-Dark Skin Tone
🫷🏿 Leftwards Pushing Hand: Dark Skin Tone
`
    m.reply(m2)
   
}

handler.help = ['audios']
handler.tags = ['main']
handler.command = ['new','emg']

export default handler