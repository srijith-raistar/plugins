let handler = async (m, { conn, text }) => {
   
    let per= `Your Link : `
    let l = text
    if (!l) m.react(`⛔`)
    m.react(`🎯`)
    conn.reply(m.chat,h+l+i, m)
}
handler.help = ['hair <emoji>'] 
handler.tags = ['tools']
handler.command = ['hair'] 

export default handler
const h = `ᥬ`
const i = `᭄`