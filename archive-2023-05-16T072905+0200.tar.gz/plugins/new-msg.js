let handler = async (m, { conn, text }) => {
   
 //   let per= `Your Link : `
    let [l, r] = text.split`$`
    
    if (!r){ r=`I%20Love%20You%20♡` ; m.react(`🛸`)}
    if (!l) m.react(`🚫`)
    
    else if((isNaN(l))) {m.react(`⛔`); m.reply (`Enter in the correct form\nEg: .msg <your number>`) }
    else
    {m.react(`🎯`)
    //conn.reply(m.chat,per+h+l+i+r, m)
    let ling=h+l+i+r;
    
    
      let res = await fetch(`https://tinyurl.com/api-create.php?url=${ling}`);
  let linkk = await res.text();
  m.reply(`Your Link = ${linkk}`);
}}
handler.help = ['msg <phone number with contry code>$<message>'] 
handler.tags = ['tools']
handler.command = ['msg'] 

export default handler
const h = `https://wa.me/`
const i = `?text=`