//import db from '../lib/database.js'

let handler = async (m, { text, conn }) => {
    let user = global.db.data.users[m.sender]
    if (user.nfp > -1) {
        m.reply(`
 Your Streak Ended...🥶💔
🧚 *Your NOFAP STREAK Duration :* ${(new Date - user.nfp).toTimeString()}
  `.trim())
        user.nfp = -1
        
    }
 /*   let jids = [...new Set([...(m.mentionedJid || []), ...(m.quoted ? [m.quoted.sender] : [])])]
    for (let jid of jids) {
        let user = global.db.data.users[jid]
        if (!user)
            continue
        let nfpTime = user.nfp
        if (!nfpTime || nfpTime < 0)
            continue
       
        m.reply(`
💤 The human u mentioned is afk 

${reason ? '▢ *Reason* : ' + reason : '▢ *Reason* : Without reason'}
▢ *AFK Duration :* ${(new Date - afkTime).toTimeString()}
  `.trim())
    }
    return true*/
}
handler.help = ['nofapfail']
handler.tags = ['tools']
handler.command = ['relapse','nofapfail']

export default handler