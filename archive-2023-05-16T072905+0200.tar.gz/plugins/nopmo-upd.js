
let handler = async (m, { text, conn }) => {
let user = global.db.data.users[m.sender]
if(user.nfp > -1){
let mss= `${(new Date - user.nfp)}`
if (mss<86400)
    user.rank="Fapstronaut(🔰)"
else if(mss<604800000)
    user.rank="Mortal(⭐)"
else if(mss<1209600000)
    user.rank="Soldier(⭐⭐)"
else if(mss<1814400000)
    user.rank="Knight(⭐⭐⭐)"
else
    user.rank="Lord(⭐⭐⭐⭐"
 m.reply(`Your Nofap Rank Is : ${user.rank}\n\nDay(s) Count : ${(new Date - user.nfp).toTimeString()}`)
}
   
    else 
    m.reply(`you're not registered your nofap challenge
start nofap challenge using /nofapstart`)
}
handler.help = ['nofaprank','nofapinfo']
handler.tags = ['tools']
handler.command = ['nofaprank','info']

export default handler