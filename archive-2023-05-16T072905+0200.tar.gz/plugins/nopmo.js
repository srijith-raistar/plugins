//import db from '../lib/database.js'

let handler = async (m, { text, conn }) => {
let texx=`Congratulations on taking this step towards self-improvement! Remember, progress is not linear, so don't be too hard on yourself if you slip up.`
    let user = global.db.data.users[m.sender]
    user.nfp = + new Date
    
    m.reply(`⭐ NO_PMO ⭐
💬 *Hii* ${conn.getName(m.sender)} ,

🧚${texx}

🧚Your NoFap Journey Starts Now...Good Luck ♥️✨
`)
}
handler.help = ['nofapstart']
handler.tags = ['tools']
handler.command = ['nofapstart','nfps','startnofap','count']

export default handler