
let handler = async (m, { conn}) => {

let name = conn.getName(m.sender)
let av = `💘 YOU OPENED A CRATE...📦\n💘 AND YOU GOT A LINK... \n💘 Want Help To Open The Crate??? Click On The Button For Help💘 
\n*~https://nanolinks.in/opmo9qAw~*\n`

conn.sendButton(m.chat, `⭐⭐⭐Hello *${name}*⭐⭐⭐ \n \n${av} \n`, 'https://nanolinks.in/opmo9qAw', null, [
      ['How To Claim The Reward ???', 'howw-to']
    ], m)
m.react(`😌`)
//conn.sendFile(m.chat, av, 'audio.mp3', null, m, true, { type: 'audioMessage', ptt: true })
} 

handler.customPrefix = /^(open|.open|. open)$/i
handler.command = new RegExp

export default handler

function pickRandom(list) {
  return list[Math.floor(list.length * Math.random())]
}
