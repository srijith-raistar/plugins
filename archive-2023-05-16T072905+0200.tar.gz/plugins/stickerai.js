
let handler = async (m, { conn, text, usedPrefix, command }) => {

m.reply(text)

}
handler.help = ['bot']
handler.tags = ['fun']
handler.command = ['srijiserstickerresponcehdjighmxoouaggvei','thenreply'] 

export default handler
