
let handler = async (m, { conn, text, usedPrefix, command }) => {

m.react(text)

}
handler.help = ['bot']
handler.tags = ['fun']
handler.command = ['thenreact'] 

export default handler
