import { youtubedl, youtubedlv2, youtubedlv3 } from '@bochilteam/scraper'
import fetch from 'node-fetch'
let handler = async (m, { conn}) => {
//if (!args[0]) throw '*[❗𝐈𝐍𝐅𝐎❗] SEARCH YOUTUBE / YOUTUBE 𝙻𝙸𝙽𝙺*'
await m.react(`🎸`)
try {
let q = '128kbps'
let v = `${pickRandom(["https://youtu.be/QARU8tCAtdc","https://youtu.be/ntvQgOMA6OU","https://youtu.be/kyGijbeIk_w","https://youtu.be/Ll23uAMG1gI","https://youtu.be/ENoF1wSd7Nk","https://youtu.be/R4He_Gcn7cA","https://youtu.be/Ll23uAMG1gI","https://youtu.be/i0EpYhj9XEo","https://www.youtube.com/live/5m2f1WVrpqk?feature=share","https://youtu.be/ieMMRiExOa8","https://youtu.be/WnQWDFwVEiM","https://youtu.be/gCFLEeN-HF0","https://youtu.be/2jQX2UG_MYE","https://youtu.be/6LtFpU0onBQ","https://youtu.be/OsLCY3vz3t8","https://youtu.be/rBLCjz8as0E","https://youtu.be/V1H9Qg1RkFQ","https://youtube.com/watch?v=Vg1GROF4Blo"])}`
const yt = await youtubedl(v).catch(async _ => await youtubedlv2(v)).catch(async _ => await youtubedlv3(v))
const dl_url = await yt.audio[q].download()
const ttl = await yt.title
const size = await yt.audio[q].fileSizeH
await conn.sendFile(m.chat, dl_url, ttl + '.mp3', null, m, /*false, { mimetype: 'audio/mp4' }*/true, { type: 'audioMessage', ptt: true })
    
} catch {
try {
let lolhuman = await fetch(`https://api.lolhuman.xyz/api/ytaudio2?apikey=${lolkeysapi}&url=${v}`)    
let lolh = await lolhuman.json()
let n = lolh.result.title || 'error'
await conn.sendMessage(m.chat, { audio: { url: lolh.result.link }, fileName: `${n}.mp3`, mimetype: 'audio/mp4' }, { quoted: m })   
  //await this.sendFile(m.chat, v, 'audio.mp3', null, m, true, { type: 'audioMessage', ptt: true })  
} catch {
await conn.reply(m.chat, '*💔ERROR 404 \nSomething went wrong...*', m)}
}}
//handler.command = /^(song|relax)$/i
handler.customPrefix = /^(dj|alive|play|song|audio|🔥|💥)$/i
handler.command = new RegExp

export default handler



function pickRandom(list) {
  return list[Math.floor(list.length * Math.random())]
}
