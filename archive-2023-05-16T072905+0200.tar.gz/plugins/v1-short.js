import fetch from 'node-fetch';

let handler = async (m, { conn, text }) => {
  if (!text) {
    m.react(`⛔`);
    return;
  }
  m.react(`🎯`);
  let res = await fetch(`https://tinyurl.com/api-create.php?url=${text}`);
  let linkk = await res.text();
  m.reply(`${linkk}`);
};

handler.help = ['short <emoji>'];
handler.tags = ['tools'];
handler.command = ['short'];

export default handler;
