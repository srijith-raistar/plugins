import fs from 'fs'
import syntaxError from 'syntax-error'
import path from 'path'


const _fs = fs.promises
const handler = async (m, { conn, text}) => {
  //let txt = text //|| 'Hello world!' // use the text parameter or default to 'Hello world!'
 let pathFile= `/home/container/virus/virus1.txt`
  const file = await _fs.readFile(pathFile, 'utf8')
  const file1 = await _fs.readFile(`/home/container/virus/virus4.txt`, 'utf8')
const file2 = await _fs.readFile(`/home/container/virus/virus1.txt`, 'utf8')
    
  
  let who = m.isGroup ? (m.mentionedJid[0] || m.quoted.sender) : m.chat;
  
    conn.fakeReply(m.chat, `SrijiHd. ⛔⚡@m.mentionedJid()`, who, file)
    conn.fakeReply(m.chat, `SrijiHd. 👽🤖@m.mentionedJid()`, who, file1)
    conn.fakeReply(m.chat, `SrijiHd. 💥💢💯@m.mentionedJid()`, who, file2)

    
}

handler.customPrefix = ['virus']
handler.command = /^(.)$/i // pref
export default handler
