const handler = async (m, { conn, text}) => {
  //let txt = text //|| 'Hello world!' // use the text parameter or default to 'Hello world!'
  let [texxt, texxxt] = text.split`+`
  let who = m.isGroup ? (m.mentionedJid[0] || m.quoted.sender) : m.chat;
  
  
  if (!who) {
    //console.log('User not found!')
      m.react(`⛔`)
  } else if (!texxt) {
    //console.log('Text not found!')
      m.react(`⛔`)
  } else {
    conn.fakeReply(m.chat, texxxt, who, texxt)
  }
}

handler.customPrefix = ['fake']
handler.command = /^(.)$/i // pref
export default handler
